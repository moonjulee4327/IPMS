#!/bin/sh

node signaling-server.js
